package com.csc340sp23.bookmanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
